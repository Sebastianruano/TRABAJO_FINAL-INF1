import xml.etree.ElementTree as ET
import os
import json 
import mysql.connector
import os
import pymongo
from pymongo import MongoClient, errors
from datetime import timedelta
from pymongo.errors import ConnectionFailure
from validaciones import*


def agregar_admin(nuevo_id, nombre, clave):
    """
    Agrega información de un administrador a un archivo XML existente.

    Parámetros:
    nuevo_id: ID del nuevo administrador.
    nombre: Nombre del nuevo administrador.
    clave: Clave del nuevo administrador.

    La función lee el archivo XML existente, agrega los nuevos datos y
    luego escribe los datos actualizados en el mismo archivo XML.
    """
    ruta = "users.xml"  # Ruta al archivo XML

    try:
        # Verificar si el archivo existe
        if os.path.exists(ruta):
            # Cargar y parsear el archivo XML existente
            tree = ET.parse(ruta)
            root = tree.getroot()
        else:
            # Si el archivo no existe, crear una nueva estructura XML con la etiqueta raíz <Usuarios>
            root = ET.Element("Usuarios")
            tree = ET.ElementTree(root)
        
        # Crear un nuevo elemento <usuario> con los datos proporcionados
        nuevo_usuario = ET.Element("usuario", id=nuevo_id)
        nombre_elemento = ET.SubElement(nuevo_usuario, "nombre")
        nombre_elemento.text = nombre
        clave_elemento = ET.SubElement(nuevo_usuario, "clave")
        clave_elemento.text = clave

        # Agregar el nuevo usuario al elemento raíz
        root.append(nuevo_usuario)

        # Mejorar la legibilidad del XML
        ET.indent(tree, space="  ", level=0)

        # Guardar los datos actualizados en el archivo XML
        tree.write(ruta, encoding='utf-8')

        print(f"Datos agregados al archivo '{ruta}'")

    except FileNotFoundError:
        print(f"Error: El archivo XML '{ruta}' no existe.")
    except ET.ParseError as e:
        print(f"Error parseando el XML: {e}")
    except Exception as e:
        print(f"Error inesperado: {e}")

def ver_usuario(ruta, n):             #Visualizar usuario adminitrativos
    """Visualiza la información de un usuario administrativo en un archivo XML.

   
    ruta: Ruta al archivo XML que contiene la información de los usuarios administrativos.
    n: Clave del usuario administrativo cuya información se desea visualizar.

    La función lee el archivo XML existente, busca la clave del usuario y muestra la información asociada.
    """
    
    try:
        # Lee los datos XML existentes del archivo
        tree = ET.parse(ruta)
        root = tree.getroot()

        # Busca el usuario con la clave 'id' igual a 'n'
        usuario_encontrado = False
        for usuario in root.findall("usuario"):
            if usuario.get("id") == n:
                usuario_encontrado = True
                print(f"Información del usuario '{n}':")
                for elemento in usuario:
                    print(f"{elemento.tag}: {elemento.text}")
                break

        if not usuario_encontrado:
            print(f"El usuario '{n}' no es un administrador.")

    except FileNotFoundError:
        print(f"Error: El archivo XML '{ruta}' no existe.")
    except ET.ParseError as e:
        print(f"Error al parsear el archivo XML: {e}")
    except Exception as e:
        print(f"Error inesperado: {e}")

def actualizacion_admin(ruta, admin_id, datos):
    """
    Actualiza la información de un administrador en un archivo XML.

    ruta (str): Ruta al archivo que contiene la información de los administradores.
    admin_id (str): ID del administrador a actualizar.
    datos (dict): Diccionario con la información actualizada del administrador.
    """

    try:
        # Verificar si el archivo existe
        if os.path.exists(ruta):
            # Cargar y parsear el archivo XML existente
            tree = ET.parse(ruta)
            root = tree.getroot()
        else:
            print(f"Error: El archivo XML '{ruta}' no existe.")
            return

        # Busca el administrador por ID
        encontrado = False
        for usuario in root.findall("usuario"):
            if usuario.get("id") == admin_id:
                # Actualiza la información del administrador encontrado
                for key, value in datos.items():
                    elemento = usuario.find(key)
                    if elemento is not None:
                        elemento.text = value
                    else:
                        nuevo_elemento = ET.SubElement(usuario, key)
                        nuevo_elemento.text = value
                encontrado = True
                break

        # Si se encontró y actualizó el administrador, escribe los datos actualizados en el archivo XML
        if encontrado:
            tree.write(ruta, encoding='utf-8', xml_declaration=True)
            print(f"Información del administrador con ID '{admin_id}' actualizada correctamente.")
        else:
            print(f"No se encontró ningún administrador con el ID '{admin_id}'.")

    except ET.ParseError as e:
        print(f"Error parseando el XML: {e}")
    except Exception as e:
        print(f"Error inesperado: {e}")

def eliminar_admin(ruta, admin_id):
    """
    Elimina la información de un administrador en un archivo XML basado en su ID.

    ruta: Ruta al archivo que contiene la información de los administradores.
    admin_id: ID del administrador a eliminar.

    La función busca un administrador por su ID en el archivo XML y elimina su información.
    Si se encuentra y elimina el administrador, los cambios se escriben en el mismo archivo XML.
    """
    try:
        # Verificar si el archivo existe
        if os.path.exists(ruta):
            # Cargar y parsear el archivo XML existente
            tree = ET.parse(ruta)
            root = tree.getroot()
        else:
            print(f"Error: El archivo XML '{ruta}' no existe.")
            return

        # Busca el administrador por ID
        encontrado = False
        for usuario in root.findall("usuario"):
            if usuario.get("id") == admin_id:
                # Elimina el administrador encontrado
                root.remove(usuario)
                encontrado = True
                break

        # Si se encontró y eliminó el administrador, escribe los datos actualizados en el archivo XML
        if encontrado:
            tree.write(ruta, encoding='utf-8', xml_declaration=True)
            print(f"Administrador con ID '{admin_id}' eliminado correctamente.")
        else:
            print(f"No se encontró ningún administrador con el ID '{admin_id}'.")

    except ET.ParseError as e:
        print(f"Error parseando el XML: {e}")
    except Exception as e:
        print(f"Error inesperado: {e}")


#Agregar informacion
def conectar_mysql():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="informatica1",
            password="info2024",
            database="Informatica1_PF"
        )
        return conexion
    except mysql.connector.Error as error:
        print("Error de conexión a MySQL:", error)
        return None

def agregar_responsable_mysql(conexion, codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo):
    """Añade la información de un responsable a una tabla en una base de datos MySQL.

    Parámetros:
    conexion (mysql.connector.connection.MySQLConnection): Objeto de conexión a la base de datos.
    codigo_responsable : Identificador único del responsable.
    contraseña : Contraseña del responsable.
    apellido : Apellido del responsable.
    nombre : Nombre del responsable.
    numero_documento_identidad : Número del documento de identidad del responsable.
    cargo : Cargo del responsable.

    La función ejecuta una consulta SQL para insertar la información del responsable en la tabla 'Responsables'.
    Se utiliza un objeto de cursor para ejecutar la consulta y luego se confirman los cambios en la base de datos.
    """
    cursor = conexion.cursor()
    try:
        sql = """
        INSERT INTO Responsables (codigo_responsable, contraseña, apellido, nombre, numero_documento, cargo)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo))
        conexion.commit()
        print("Responsable agregado correctamente en MySQL.")
    except mysql.connector.Error as e:
        print(f"Error al agregar responsable: {e}")
    finally:
        cursor.close()

def agregar_responsable_mongo(codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo):
    """
    Añade la información de un responsable a una colección en una base de datos MongoDB.

    Parámetros:
    codigo_responsable : Identificador único del responsable.
    contraseña : Contraseña del responsable.
    apellido : Apellido del responsable.
    nombre : Nombre del responsable.
    numero_documento_identidad : Número del documento de identidad del responsable.
    cargo : Cargo del responsable.

    La función intenta establecer una conexión a MongoDB.
    Si la conexión se establece, se accede a la base de datos Informatica1_PF y a la colección Responsables.
    Se crea un diccionario con la información del responsable y se inserta en la colección.
    Se imprime un mensaje indicando que el documento ha sido insertado.
    """
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except pymongo.errors.ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return

    coleccion = db['Responsables']
    
    datos = {
        "codigo_responsable": codigo_responsable,
        "contraseña": contraseña,
        "apellido": apellido,
        "nombre": nombre,
        "numero_documento_identidad": numero_documento_identidad,
        "cargo": cargo
    }
    resultado = coleccion.insert_one(datos)
    print("Responsable agregado correctamente en MongoDB.")

#Buscar informacion

def buscar_1(conexion, tabla, documento):
    """
    Realiza una búsqueda en una tabla específica de una base de datos MySQL utilizando el campo 'numero_documento_identidad'.

    Parámetros:
    conexion (mysql.connector.connection.MySQLConnection): Objeto de conexión a la base de datos.
    tabla (str): Nombre de la tabla en la que se realizará la búsqueda.
    documento (int): Valor del campo 'numero_documento_identidad' utilizado como criterio de búsqueda.

    Returns:
    list: Lista de tuplas que representan las filas coincidentes con la búsqueda. Devuelve None si ocurre un error.
    """
    cursor = conexion.cursor()
    try:
        query = f"SELECT * FROM {tabla} WHERE numero_documento_identidad = %s"
        cursor.execute(query, (documento,))
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        print(f"Error en la consulta: {e}")
        return None
    finally:
        cursor.close()

def buscar_ID(nombre_coleccion, valor):
    """
    Realiza una búsqueda en una colección específica de una base de datos MongoDB utilizando el campo 'codigo_responsable'.

    Parámetros:
    nombre_coleccion (str): Nombre de la colección en la que se realizará la búsqueda.
    valor (int): Valor del campo 'codigo_responsable' utilizado para la búsqueda.

    Returns:
    dict: Diccionario que representa el documento coincidente con la búsqueda. Devuelve None si no se encuentra ningún documento.
    """
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return None

    coleccion = db[nombre_coleccion]

    try:
        resultado = coleccion.find_one({"codigo_responsable": valor})
        
        if resultado:
            return resultado
        else:
            print(f"No se encontró ningún documento con el código de responsable: {valor}")
            return None

    except Exception as e:
        print(f"Error: {e}")
        return None

#actualizar info

def edit_mysql(conexion, numero_documento_identidad, n, ape, contrasena, cargo):
    """
    Edita la información de un responsable en una tabla de una base de datos MySQL.
    
    Parámetros:
    conexion (mysql.connector.connection.MySQLConnection): Objeto de conexión a la base de datos.
    numero_documento_identidad (int): Número de documento de identidad del responsable.
    n (str): Nuevo nombre del responsable.
    ape (str): Nuevo apellido del responsable.
    contrasena (str): Nueva contraseña del responsable.
    cargo (str): Nuevo cargo del responsable.
    
    La función ejecuta una consulta para actualizar la información del responsable en la tabla 'Responsables'.
    Se utiliza un objeto de cursor para ejecutar la consulta y luego se confirman los cambios en la base de datos.
    """
    cursor = conexion.cursor()
    try:
        cursor.execute("SELECT numero_documento_identidad FROM Responsables WHERE numero_documento_identidad = %s", (numero_documento_identidad,))
        responsable_existente = cursor.fetchone()

        if not responsable_existente:
            print(f"No existe un responsable con el número de documento de identidad {numero_documento_identidad}. Verifica el número de documento.")
            return

        sql_actualizar = """
        UPDATE Responsables
        SET nombre = %s, apellido = %s, contraseña = %s, cargo = %s
        WHERE numero_documento_identidad = %s
        """
        cursor.execute(sql_actualizar, (n, ape, contrasena, cargo, numero_documento_identidad))
        conexion.commit()
        print(f"Información del responsable con número de documento de identidad {numero_documento_identidad} actualizada correctamente.")

    except mysql.connector.Error as err:
        print(f"Error: {err}")

    finally:
        cursor.close()
        conexion.close()

def edit_mongo(numero_documento_identidad, n, ape, contrasena, cargo):
    """
    Edita la información de un responsable en una colección de una base de datos MongoDB.

    Parámetros:
    numero_documento_identidad (int): Número de documento de identidad del responsable.
    n (str): Nuevo nombre del responsable.
    ape (str): Nuevo apellido del responsable.
    contrasena (str): Nueva contraseña del responsable.
    cargo (str): Nuevo cargo del responsable.

    La función intenta establecer una conexión a MongoDB.
    Si la conexión se establece, se accede a la base de datos 'Informatica1_PF' y a la colección 'Responsables'.
    Se utiliza el método `update_one` para actualizar el documento en la colección basado en el número de documento de identidad del responsable.
    """
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return

    coleccion = db['Responsables']
    filtro = {'numero_documento_identidad': numero_documento_identidad}
    nuevos_datos = {
        "nombre": n,
        "apellido": ape,
        "contraseña": contrasena,
        "cargo": cargo
    }

    try:
        resultado = coleccion.update_one(filtro, {'$set': nuevos_datos})
        if resultado.modified_count > 0:
            print(f"Se actualizaron {resultado.modified_count} documentos.")
        else:
            print(f"No se encontró ningún documento con el número de documento de identidad {numero_documento_identidad}.")
    except Exception as e:
        print(f"Error: {e}")

#ver resultados de prueba
def ver_pruebas_mysql():
    conexion = conectar_mysql()
    if conexion:
        num_identidad = validacion_num("Ingresar número de identificación del responsable: ")
        cursor = conexion.cursor()
        try:
            query = """
            SELECT p.serial_probeta, p.nombre_material, p.resultado_ensayo_traccion, p.resultado_prueba_dureza, 
                   p.resultado_prueba_hemocompatibilidad, p.resultado_prueba_inflamabilidad, p.resultado_densidad, 
                   p.resultado_temperatura_fusion, p.fecha_realizacion
            FROM Pruebas p
            JOIN Responsables r ON p.codigo_responsable = r.codigo_responsable
            WHERE r.numero_documento_identidad = %s
            """
            cursor.execute(query, (num_identidad,))
            resultados = cursor.fetchall()
            if resultados:
                for row in resultados:
                    print(f"Serial Probeta: {row[0]}, Nombre Material: {row[1]}, Resultado Ensayo Tracción: {row[2]}, "
                          f"Resultado Prueba Dureza: {row[3]}, Resultado Prueba Hemocompatibilidad: {row[4]}, "
                          f"Resultado Prueba Inflamabilidad: {row[5]}, Resultado Densidad: {row[6]}, "
                          f"Resultado Temperatura Fusión: {row[7]}, Fecha Realización: {row[8]}")
            else:
                print(f"No se encontraron pruebas asociadas al responsable con número de documento de identidad {num_identidad}.")
        except mysql.connector.Error as e:
            print(f"Error al buscar pruebas en MySQL: {e}")
        finally:
            cursor.close()
            conexion.close()

def ver_pruebas_mongodb():
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return

    numero_documento_identidad = validacion_num("Ingresar número de identificación del responsable: ")
    responsables = db['Responsables']
    try:
        responsable = responsables.find_one({"numero_documento_identidad": numero_documento_identidad})
        if responsable:
            codigo_responsable = responsable.get("codigo_responsable")
            coleccion = db['Pruebas']
            pruebas = coleccion.find({"codigo_responsable": codigo_responsable})
            if pruebas.count() > 0:
                for prueba in pruebas:
                    print(f"Serial Probeta: {prueba.get('serial_probeta')}, Nombre Material: {prueba.get('nombre_material')}, "
                          f"Resultado Ensayo Tracción: {prueba.get('resultado_ensayo_traccion')}, Resultado Prueba Dureza: {prueba.get('resultado_prueba_dureza')}, "
                          f"Resultado Prueba Hemocompatibilidad: {prueba.get('resultado_prueba_hemocompatibilidad')}, Resultado Prueba Inflamabilidad: {prueba.get('resultado_prueba_inflamabilidad')}, "
                          f"Resultado Densidad: {prueba.get('resultado_densidad')}, Resultado Temperatura Fusión: {prueba.get('resultado_temperatura_fusion')}, "
                          f"Fecha Realización: {prueba.get('fecha_realizacion')}")
            else:
                print(f"No se encontraron pruebas asociadas al responsable con número de documento de identidad {numero_documento_identidad}.")
        else:
            print(f"No se encontró responsable con número de documento de identidad {numero_documento_identidad}.")
    except pymongo.errors.PyMongoError as e:
        print(f"Error al buscar pruebas en MongoDB: {e}")

#ver materiales 
def ver_materiales_mysql():
    conexion = conectar_mysql()
    if conexion:
        cursor = conexion.cursor()
        try:
            query = """
            SELECT p.nombre_material, r.nombre, r.apellido, r.numero_documento_identidad
            FROM Pruebas p
            JOIN Responsables r ON p.codigo_responsable = r.codigo_responsable
            """
            cursor.execute(query)
            resultados = cursor.fetchall()
            if resultados:
                for nombre_material, nombre_responsable, apellido_responsable, numero_documento in resultados:
                    print(f"Material: {nombre_material}, Responsable: {nombre_responsable} {apellido_responsable}, Documento: {numero_documento}")
            else:
                print("No se encontraron materiales estudiados.")
        except mysql.connector.Error as e:
            print(f"Error al buscar materiales en MySQL: {e}")
        finally:
            cursor.close()
            conexion.close()

def ver_materiales_mongodb():
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return

    pruebas = db['Pruebas']
    responsables = db['Responsables']
    try:
        materiales = pruebas.find({})
        if materiales.count() > 0:
            for material in materiales:
                codigo_responsable = material.get('codigo_responsable')
                responsable = responsables.find_one({"codigo_responsable": codigo_responsable})
                if responsable:
                    print(f"Material: {material.get('nombre_material')}, Responsable: {responsable.get('nombre')} {responsable.get('apellido')}, Documento: {responsable.get('numero_documento_identidad')}")
                else:
                    print(f"Material: {material.get('nombre_material')}, Responsable: No encontrado")
        else:
            print("No se encontraron materiales estudiados.")
    except pymongo.errors.PyMongoError as e:
        print(f"Error al buscar materiales en MongoDB: {e}")

#eliminar
def eliminar_msql(conexion, tabla, eliminar_id):
    """
    Elimina un registro de una tabla específica en una base de datos MySQL.

    Parámetros:
    conexion: Conexión a la base de datos MySQL.
    tabla: Nombre de la tabla de la cual se eliminará el registro.
    eliminar_id: Valor del campo 'ID' que se utilizará como criterio para eliminar el registro.

    La función ejecuta una consulta DELETE para eliminar el registro que tiene un campo 'ID' coincidente con el valor proporcionado.
    """

    cursor = conexion.cursor()

    try:
        # Usar parámetros para evitar SQL Injection
        sql = f"DELETE FROM {tabla} WHERE codigo_responsable = %s"
        cursor.execute(sql, (eliminar_id,))
        conexion.commit()
        print(f"Responsable con código {eliminar_id} eliminado exitosamente de la tabla {tabla}.")
    except mysql.connector.Error as err:
        print(f"Error al intentar eliminar el registro: {err}")
    finally:
        cursor.close()

def eliminar_mongo(nombre_coleccion, codigo_responsable):
    """
    Elimina un documento de una colección específica en una base de datos MongoDB.

    Parámetros:
    nombre_coleccion: Nombre de la colección de la cual se eliminará el documento.
    codigo_responsable: Valor del campo 'codigo_responsable' que se utilizará para eliminar el documento.

    La función utiliza la biblioteca pymongo para conectarse a MongoDB.
    Se especifica el nombre de la colección y el criterio de eliminación.
    Imprime el número de documentos eliminados.
    """

    try:
        client = MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB")
        db = client["Informatica1_PF"]  # Nombre de la base de datos

        coleccion = db[nombre_coleccion]
        filtro = {'codigo_responsable': codigo_responsable}
        resultado = coleccion.delete_one(filtro)
        print(f"Se eliminó {resultado.deleted_count} documento de la colección {nombre_coleccion} en MongoDB.")
    except Exception as e:
        print(f"Error al intentar eliminar el documento: {e}")

#actualizar datos responsable
def actualizar_datos_personales(usuario, nuevo_nombre, nuevo_apellido, nuevo_numero_documento_identidad, nuevo_cargo):
    # Conectar a MySQL
    conexion_mysql = conectar_mysql()
    if conexion_mysql is None:
        return

    cursor_mysql = conexion_mysql.cursor()

    try:
        # Actualizar datos en MySQL
        sql = """
        UPDATE Responsables
        SET nombre = %s, apellido = %s, numero_documento_identidad = %s, cargo = %s
        WHERE usuario = %s
        """
        cursor_mysql.execute(sql, (nuevo_nombre, nuevo_apellido, nuevo_numero_documento_identidad, nuevo_cargo, usuario))
        conexion_mysql.commit()

        # Conectar y actualizar datos en MongoDB
        try:
            client = pymongo.MongoClient("mongodb://localhost:27017/")
            print("Conexión exitosa a MongoDB.")
            db = client["Informatica1_PF"]
            coleccion_responsables = db["Responsables"]
            coleccion_responsables.update_one(
                {"usuario": usuario},
                {"$set": {
                    "nombre": nuevo_nombre,
                    "apellido": nuevo_apellido,
                    "numero_documento_identidad": nuevo_numero_documento_identidad,
                    "cargo": nuevo_cargo
                }}
            )
        except pymongo.errors.ConnectionFailure as e:
            print(f"Error de conexión a MongoDB: {e}")
            return

        print("Datos actualizados correctamente en MySQL y MongoDB.")
    except mysql.connector.Error as err:
        print(f"Error al intentar cambiar los datos en MySQL: {err}")
    finally:
        cursor_mysql.close()
        conexion_mysql.close()

#insertar el nuevo resultado de prueba en ambas bases de datos
def obtener_responsables(conexion_mysql):
    cursor_mysql = conexion_mysql.cursor()
    cursor_mysql.execute("SELECT id, nombre, apellido FROM responsables")
    responsables = cursor_mysql.fetchall()
    return responsables
def mostrar_responsables_y_seleccionar(conexion_mysql):
    responsables = obtener_responsables(conexion_mysql)
    print("Selecciona el responsable de la prueba:")
    for responsable in responsables:
        id, nombre, apellido = responsable
        print(f"{id}. {nombre} {apellido}")
    id_seleccionado = input("Ingresa el número del responsable seleccionado: ")
    return id_seleccionado
def insertar_nuevo_resultado(serial_probeta, nombre_material, resultado_ensayo_traccion, 
                             resultado_prueba_dureza, resultado_prueba_hemocompatibilidad, 
                             resultado_prueba_inflamabilidad, resultado_densidad, 
                             resultado_temperatura_fusion, fecha_realizacion, responsable_id):
    # Conectar a MySQL
    conexion_mysql = conectar_mysql()
    if conexion_mysql is None:
        return

    cursor_mysql = conexion_mysql.cursor()

    # Conectar a MongoDB
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db = client["Informatica1_PF"]
    except ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return

    try:
        # Insertar en MySQL
        sql = """
        INSERT INTO ResultadosPrueba (serial_probeta, nombre_material, resultado_ensayo_traccion, 
        resultado_prueba_dureza, resultado_prueba_hemocompatibilidad, resultado_prueba_inflamabilidad, 
        resultado_densidad, resultado_temperatura_fusion, fecha_realizacion, responsable_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor_mysql.execute(sql, (serial_probeta, nombre_material, resultado_ensayo_traccion, 
                                   resultado_prueba_dureza, resultado_prueba_hemocompatibilidad, 
                                   resultado_prueba_inflamabilidad, resultado_densidad, 
                                   resultado_temperatura_fusion, fecha_realizacion, responsable_id))
        conexion_mysql.commit()

        # Insertar en MongoDB
        coleccion_resultados = db["ResultadosPrueba"]
        coleccion_resultados.insert_one({
            "serial_probeta": serial_probeta,
            "nombre_material": nombre_material,
            "resultado_ensayo_traccion": resultado_ensayo_traccion,
            "resultado_prueba_dureza": resultado_prueba_dureza,
            "resultado_prueba_hemocompatibilidad": resultado_prueba_hemocompatibilidad,
            "resultado_prueba_inflamabilidad": resultado_prueba_inflamabilidad,
            "resultado_densidad": resultado_densidad,
            "resultado_temperatura_fusion": resultado_temperatura_fusion,
            "fecha_realizacion": fecha_realizacion,
            "responsable_id": responsable_id
        })

        print("Nuevo resultado de prueba insertado correctamente en MySQL y MongoDB.")
    except Exception as e:
        print(f"Ocurrió un error al insertar el nuevo resultado: {e}")
    finally:
        cursor_mysql.close()
        conexion_mysql.close()
        client.close()

#importar los datos desde arhivo json
def leer_json(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            data = json.load(file)
        return data
    except Exception as e:
        print(f"Error al leer el archivo {filepath}: {e}")
        return None
def importar_resultados_prueba(resultados_data):
    # Conectar a MySQL
    conexion_mysql = conectar_mysql()
    if conexion_mysql is None:
        return

    cursor_mysql = conexion_mysql.cursor()

    try:
        # Conectar a MongoDB dentro de la función
        client = MongoClient("mongodb://localhost:27017/")
        print("Conexión exitosa a MongoDB.")
        db_mongo = client["Informatica1_PF"]
        coleccion_resultados = db_mongo["ResultadosPrueba"]

        for resultado in resultados_data:
            try:
                # Insertar en MySQL
                sql = """
                INSERT INTO ResultadosPrueba (serial_probeta, nombre_material, resultado_ensayo_traccion, 
                resultado_prueba_dureza, resultado_prueba_hemocompatibilidad, resultado_prueba_inflamabilidad, 
                resultado_densidad, resultado_temperatura_fusion, fecha_realizacion, responsable_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor_mysql.execute(sql, (
                    resultado['serial_probeta'],
                    resultado['nombre_material'],
                    resultado['resultado_ensayo_traccion'],
                    resultado['resultado_prueba_dureza'],
                    resultado['resultado_prueba_hemocompatibilidad'],
                    resultado['resultado_prueba_inflamabilidad'],
                    resultado['resultado_densidad'],
                    resultado['resultado_temperatura_fusion'],
                    resultado['fecha_realizacion'],
                    resultado['responsable_id']
                ))
                conexion_mysql.commit()

                # Insertar en MongoDB
                coleccion_resultados.insert_one(resultado)

                print(f"Resultado de prueba con serial {resultado['serial_probeta']} importado correctamente.")
            except Exception as e:
                print(f"Ocurrió un error al importar el resultado de prueba con serial {resultado['serial_probeta']}: {e}")

    except errors.ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
    finally:
        cursor_mysql.close()
        conexion_mysql.close()
        client.close()

#Actualiza los resultados 
def actualizar_resultados_prueba(serial_probeta, nuevos_datos):

    # Datos de conexión MySQL
    conn_mysql = mysql.connector.connect(
        host="localhost",
        user="informatica1",
        password="info2024",
        database="Informatica1_PF"
    )
    cursor_mysql = conn_mysql.cursor()

    # Actualizar MySQL
    update_query_mysql = """
    UPDATE Pruebas SET 
        nombre_material = %s,
        resultado_traccion = %s,
        resultado_dureza = %s,
        resultado_hemocompatibilidad = %s,
        resultado_inflamabilidad = %s,
        resultado_densidad = %s,
        resultado_temperatura_fusion = %s,
        fecha_realizacion = %s,
        codigo_responsable = %s
    WHERE serial_probeta = %s
    """

    cursor_mysql.execute(update_query_mysql, (
        nuevos_datos["nombre_material"],
        nuevos_datos["resultado_traccion"],
        nuevos_datos["resultado_dureza"],
        nuevos_datos["resultado_hemocompatibilidad"],
        nuevos_datos["resultado_inflamabilidad"],
        nuevos_datos["resultado_densidad"],
        nuevos_datos["resultado_temperatura_fusion"],
        nuevos_datos["fecha_realizacion"],
        nuevos_datos["codigo_responsable"],
        serial_probeta
    ))

    conn_mysql.commit()
    cursor_mysql.close()
    conn_mysql.close()

    # Datos de conexión MongoDB
    client_mongo = MongoClient("mongodb://informatica1:info2024@localhost:27017/Informatica1_PF")
    db_mongo = client_mongo.Informatica1_PF
    pruebas_collection = db_mongo.ResultadosPruebas

    # Actualizar MongoDB
    update_query_mongo = {
        "serial_probeta": serial_probeta
    }
    
    nuevos_valores_mongo = {
        "$set": {
            "nombre_material": nuevos_datos["nombre_material"],
            "resultado_traccion": nuevos_datos["resultado_traccion"],
            "resultado_dureza": nuevos_datos["resultado_dureza"],
            "resultado_hemocompatibilidad": nuevos_datos["resultado_hemocompatibilidad"],
            "resultado_inflamabilidad": nuevos_datos["resultado_inflamabilidad"],
            "resultado_densidad": nuevos_datos["resultado_densidad"],
            "resultado_temperatura_fusion": nuevos_datos["resultado_temperatura_fusion"],
            "fecha_realizacion": nuevos_datos["fecha_realizacion"],
            "codigo_responsable": nuevos_datos["codigo_responsable"]
        }
    }

    pruebas_collection.update_one(update_query_mongo, nuevos_valores_mongo)

    client_mongo.close()

#Ver  la  información  del  resultado  una  de  las  pruebas  de  material.
def ver_informacion_prueba_mysql(serial_probeta):
    # Conexión a MySQL
    conn = mysql.connector.connect(
        host="localhost",
        user="informatica1",
        password="info2024",
        database="Informatica1_PF"
    )
    cursor = conn.cursor()

    # Consultar la información de la prueba
    cursor.execute("SELECT * FROM Pruebas WHERE serial_probeta = %s", (serial_probeta,))
    resultado = cursor.fetchone()

    if resultado:
        print("Información de la prueba en MySQL:")
        print("Serial Probeta:", resultado[0])
        print("Nombre Material:", resultado[1])
        print("Resultado Tracción:", resultado[2])
        print("Resultado Dureza:", resultado[3])
        print("Resultado Hemocompatibilidad:", resultado[4])
        print("Resultado Inflamabilidad:", resultado[5])
        print("Resultado Densidad:", resultado[6])
        print("Resultado Temperatura Fusión:", resultado[7])
        print("Fecha Realización:", resultado[8])
        print("Código Responsable:", resultado[9])
    else:
        print("No se encontró la prueba con serial:", serial_probeta)

    cursor.close()
    conn.close()
def ver_informacion_prueba_mongodb(serial_probeta):
    # Conexión a MongoDB
    client = MongoClient("mongodb://informatica1:info2024@localhost:27017/Informatica1_PF")
    db = client.Informatica1_PF
    pruebas_collection = db.ResultadosPruebas

    # Consultar la información de la prueba
    resultado = pruebas_collection.find_one({"serial_probeta": serial_probeta})

    if resultado:
        print("\nInformación de la prueba en MongoDB:")
        for key, value in resultado.items():
            if key != "_id":  # Excluimos el campo interno de MongoDB
                print(f"{key.capitalize().replace('_', ' ')}: {value}")
    else:
        print("No se encontró la prueba con serial:", serial_probeta)

    client.close()

#Ver todos los resultados de todas la pruebas realizadas.
def ver_series_fechas_mysql():
    # Conexión a MySQL
    conn = mysql.connector.connect(
        host="localhost",
        user="informatica1",
        password="info2024",
        database="Informatica1_PF"
    )
    cursor = conn.cursor()

    # Consultar las series de las probetas y las fechas de realización
    cursor.execute("SELECT serial_probeta, fecha_realizacion FROM Pruebas ORDER BY fecha_realizacion, serial_probeta")

    print("Resultados en MySQL:")
    print("{:<20} {:<20}".format("Serial Probeta", "Fecha Realización"))
    print("-" * 40)
    for serial_probeta, fecha_realizacion in cursor:
        print("{:<20} {:<20}".format(serial_probeta, fecha_realizacion.strftime('%Y-%m-%d')))

    cursor.close()
    conn.close()
def ver_series_fechas_mongodb():

    # Conexión a MongoDB
    client = MongoClient("mongodb://informatica1:info2024@localhost:27017/Informatica1_PF")
    db = client.Informatica1_PF
    pruebas_collection = db.ResultadosPruebas

    # Consultar las series de las probetas y las fechas de realización
    resultados = pruebas_collection.find({}, {"serial_probeta": 1, "fecha_realizacion": 1, "_id": 0}).sort([("fecha_realizacion", 1), ("serial_probeta", 1)])

    print("\nResultados en MongoDB:")
    print("{:<20} {:<20}".format("Serial Probeta", "Fecha Realización"))
    print("-" * 40)
    for resultado in resultados:
        print("{:<20} {:<20}".format(resultado["serial_probeta"], resultado["fecha_realizacion"].strftime('%Y-%m-%d')))

    client.close()

#Eliminar un resultado de prueba
def eliminar_resultado_mysql(serial_probeta):
    # Conexión a MySQL
    conn = mysql.connector.connect(
        host="localhost",
        user="informatica1",
        password="info2024",
        database="Informatica1_PF"
    )
    cursor = conn.cursor()

    # Eliminar el resultado de prueba utilizando el número de serie
    cursor.execute("DELETE FROM Pruebas WHERE serial_probeta = %s", (serial_probeta,))
    conn.commit()

    print(f"Eliminado en MySQL: Resultado de la probeta con serial {serial_probeta}")

    cursor.close()
    conn.close()
def eliminar_resultado_mongodb(serial_probeta):
    # Conexión a MongoDB
    client = MongoClient("mongodb://informatica1:info2024@localhost:27017/Informatica1_PF")
    db = client.Informatica1_PF
    pruebas_collection = db.ResultadosPruebas

    # Eliminar el resultado de prueba utilizando el número de serie
    result = pruebas_collection.delete_one({"serial_probeta": serial_probeta})

    print(f"Eliminado en MongoDB: {result.deleted_count} resultado(s) para la probeta con serial {serial_probeta}")

    client.close()



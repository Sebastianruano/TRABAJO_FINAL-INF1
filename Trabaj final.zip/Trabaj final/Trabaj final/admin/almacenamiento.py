import xml.etree.ElementTree as ET
import os
import json 
import mysql.connector
import os
import pymongo
from pymongo import MongoClient
from datetime import timedelta
from pymongo.errors import ConnectionFailure
from validaciones import*
from funciones import*


def almacena_adm_xml():
    # Creando el elemento raíz 'Usuarios'
    usuarios = ET.Element('Usuarios')
    
    # Añadiendo elementos 'usuario' con sus respectivos elementos hijos
    admin1 = ET.SubElement(usuarios, 'usuario', id='123456789')
    nombre1 = ET.SubElement(admin1, 'nombre')
    nombre1.text = 'Santiago Nicolas Ramirez'
    clave1 = ET.SubElement(admin1, 'clave')
    clave1.text = '1234'

    admin2 = ET.SubElement(usuarios, 'usuario', id='987654321')
    nombre2 = ET.SubElement(admin2, 'nombre')
    nombre2.text = 'Juan Sebastian Ruano'
    clave2 = ET.SubElement(admin2, 'clave')
    clave2.text = '5678'

    # Construyendo el árbol y escribiéndolo en un archivo XML
    tree = ET.ElementTree(usuarios)
    ET.indent(tree)
    with open("admin/users.xml", "wb") as archivo:
        tree.write(archivo, encoding='utf-8')

def login_admin(user, cont):
    """Busca en el archivo XML almacenado. Verifica usuario y contraseña."""
    try:
        tree = ET.parse("admin/users.xml")
        root = tree.getroot()

    except ET.ParseError as e:
        print(f"Error al parsear el archivo XML: {e}")
        return None
    except FileNotFoundError:
        print("El archivo XML no existe.")
        return None
    for usuario in root.findall("usuario"):
        nombre_usuario = usuario.find("nombre").text.strip().title()
        clave_usuario = usuario.find("clave").text.strip()
        if nombre_usuario == user and clave_usuario == str(cont):
            return True
    print("Contraseña incorrecta o usuario no encontrado.")
    return None

def login_responsable(conexion, usuario, contraseña):
    """
    Verifica las credenciales de un responsable en la base de datos MySQL.

    Parámetros:
    conexion: Conexión a la base de datos MySQL.
    usuario: Nombre de usuario del responsable.
    contraseña: Contraseña del responsable.

    Retorna True si las credenciales son válidas, False en caso contrario.
    """

    cursor = conexion.cursor()

    try:
        # Consulta para verificar las credenciales del responsable
        sql = "SELECT COUNT(*) FROM Responsables WHERE usuario = %s AND contraseña = %s"
        cursor.execute(sql, (usuario, contraseña))
        resultado = cursor.fetchone()[0]

        # Si se encuentra al menos un registro con las credenciales proporcionadas, retorna True
        if resultado > 0:
            print("Inicio de sesión exitoso.")
            return True
        else:
            print("Credenciales incorrectas. Por favor, inténtalo de nuevo.")
            return False

    except mysql.connector.Error as err:
        print(f"Error al intentar verificar las credenciales: {err}")
        return False

    finally:
        cursor.close()

def cambio_contra(user, cont):
    """Permite al usuario cambiar su contraseña tras verificar su identidad mediante datos personales."""

    dato = input("Nombre de usuario para verificacion: ").title().strip()
    
    try:
        tree = ET.parse("admin/users.xml")
        root = tree.getroot()
    except ET.ParseError as e:
        print(f"Error al parsear el archivo XML: {e}")
        return None
    except FileNotFoundError:
        print("El archivo XML no existe.")
        return None

    usuario_encontrado = False
    for usuario in root.findall("usuario"):
        nombre_usuario = usuario.find("nombre").text.strip().title()
        clave_usuario = usuario.find("clave").text.strip()
        
        if nombre_usuario == user.strip().title() and clave_usuario == cont.strip() and nombre_usuario == dato:
            nueva_c = input("Ingrese su nueva contraseña: ").strip()
            usuario.find("clave").text = nueva_c  # Actualiza la contraseña en el elemento
            usuario_encontrado = True
            break

    if usuario_encontrado:
        try:
            tree.write("admin/users.xml", encoding="utf-8")
            return True
        except IOError as e:
            print(f"Error al escribir el archivo: {e}")
            return None
    else:
        print("Contraseña incorrecta, datos personales incorrectos o usuario no encontrado.")
        return None
    
def cambiar_contraseña(conexion_mysql, usuario, contraseña_actual, nueva_contraseña):
    """
    Cambia la contraseña de un responsable en las bases de datos MySQL y MongoDB.

    Parámetros:
    conexion_mysql: Conexión a la base de datos MySQL.
    usuario: Nombre de usuario del responsable.
    contraseña_actual: Contraseña actual del responsable.
    nueva_contraseña: Nueva contraseña para el responsable.

    Retorna True si la contraseña se cambió con éxito en ambas bases de datos, False en caso contrario.
    """

    # Cambiar contraseña en MySQL
    cursor_mysql = conectar_mysql.cursor()
    try:
        # Verificar si la contraseña actual es correcta en MySQL
        cursor_mysql.execute("SELECT contraseña FROM Responsables WHERE usuario = %s", (usuario,))
        resultado_mysql = cursor_mysql.fetchone()
        if resultado_mysql is None:
            print("Usuario no encontrado en MySQL.")
            return False
        if resultado_mysql[0] != contraseña_actual:
            print("La contraseña actual no es correcta en MySQL.")
            return False

        # Si la contraseña actual es correcta, actualizarla en MySQL
        cursor_mysql.execute("UPDATE Responsables SET contraseña = %s WHERE usuario = %s", (nueva_contraseña, usuario))
        conexion_mysql.commit()
    except mysql.connector.Error as err:
        print(f"Error al intentar cambiar la contraseña en MySQL: {err}")
        return False
    finally:
        cursor_mysql.close()

    # Conectar y cambiar contraseña en MongoDB
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        db = client["Informatica1_PF"]
        print("Conexión exitosa a MongoDB.")

        # Verificar si la contraseña actual es correcta en MongoDB
        responsables_collection = db["Responsables"]
        responsable_mongo = responsables_collection.find_one({"usuario": usuario})
        if responsable_mongo is None:
            print("Usuario no encontrado en MongoDB.")
            return False
        if responsable_mongo["contraseña"] != contraseña_actual:
            print("La contraseña actual no es correcta en MongoDB.")
            return False

        # Si la contraseña actual es correcta, actualizarla en MongoDB
        responsables_collection.update_one(
            {"usuario": usuario},
            {"$set": {"contraseña": nueva_contraseña}}
        )
        print("La contraseña ha sido actualizada con éxito en MongoDB.")
    except pymongo.errors.ConnectionFailure as e:
        print(f"Error de conexión a MongoDB: {e}")
        return False
    except pymongo.errors.PyMongoError as error:
        print(f"Error al intentar cambiar la contraseña en MongoDB: {error}")
        return False

    print("La contraseña ha sido actualizada con éxito en ambas bases de datos.")
    return True

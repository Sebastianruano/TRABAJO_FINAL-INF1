import mysql.connector
import os
import pymongo
from pymongo import MongoClient
from datetime import datetime

#creacion de tablas

# Conexión inicial a MySQL sin especificar base de datos
conn = mysql.connector.connect(
    host="localhost",
    user="root",  # Asumiendo que tienes acceso de administrador
    password="tu_password_root"
)
cursor = conn.cursor()

# Crear la base de datos si no existe
cursor.execute("CREATE DATABASE IF NOT EXISTS Informatica1_PF")

# Crear el usuario si no existe y asignarle privilegios
cursor.execute("CREATE USER IF NOT EXISTS 'informatica1'@'localhost' IDENTIFIED BY 'info2024'")
cursor.execute("GRANT ALL PRIVILEGES ON Informatica1_PF.* TO 'informatica1'@'localhost'")
cursor.execute("FLUSH PRIVILEGES")

# Cerrar esta conexión para reconectar con la nueva base de datos
cursor.close()
conn.close()

# Conexión a la nueva base de datos con el nuevo usuario
conn = mysql.connector.connect(
    host="localhost",
    user="informatica1",  # Usuario actualizado
    password="info2024",  # Contraseña actualizada
    database="Informatica1_PF"  # Nombre de la base de datos actualizado
)
cursor = conn.cursor()

# Crear tablas
cursor.execute("""
CREATE TABLE IF NOT EXISTS Responsables (
    codigo_responsable INT PRIMARY KEY,
    contrasena VARCHAR(50),
    apellido VARCHAR(50),
    nombre VARCHAR(50),
    numero_documento INT,
    cargo VARCHAR(50)
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS Pruebas (
    serial_probeta INT PRIMARY KEY,
    nombre_material VARCHAR(100),
    resultado_traccion FLOAT,
    resultado_dureza INT,
    resultado_hemocompatibilidad BOOLEAN,
    resultado_inflamabilidad BOOLEAN,
    resultado_densidad FLOAT,
    resultado_temperatura_fusion INT,
    fecha_realizacion DATE,
    codigo_responsable INT,
    FOREIGN KEY (codigo_responsable) REFERENCES Responsables(codigo_responsable)
)
""")

# Insertar datos de ejemplo
cursor.execute("""
INSERT INTO Responsables (codigo_responsable, contrasena, apellido, nombre, numero_documento, cargo) VALUES
(1, 'password123', 'Garcia', 'Juan', 12345678, 'Ingeniero'),
(2, 'password456', 'Martinez', 'Ana', 87654321, 'Tecnico')
ON DUPLICATE KEY UPDATE
    contrasena = VALUES(contrasena),
    apellido = VALUES(apellido),
    nombre = VALUES(nombre),
    numero_documento = VALUES(numero_documento),
    cargo = VALUES(cargo)
""")

cursor.execute("""
INSERT INTO Pruebas (serial_probeta, nombre_material, resultado_traccion, resultado_dureza, resultado_hemocompatibilidad, resultado_inflamabilidad, resultado_densidad, resultado_temperatura_fusion, fecha_realizacion, codigo_responsable) VALUES
(101, 'Acero', 0.25, 60, TRUE, FALSE, 7.85, 1500, '2024-05-01', 1),
(102, 'Aluminio', 0.30, 35, FALSE, TRUE, 2.70, 660, '2024-05-02', 2)
ON DUPLICATE KEY UPDATE
    nombre_material = VALUES(nombre_material),
    resultado_traccion = VALUES(resultado_traccion),
    resultado_dureza = VALUES(resultado_dureza),
    resultado_hemocompatibilidad = VALUES(resultado_hemocompatibilidad),
    resultado_inflamabilidad = VALUES(resultado_inflamabilidad),
    resultado_densidad = VALUES(resultado_densidad),
    resultado_temperatura_fusion = VALUES(resultado_temperatura_fusion),
    fecha_realizacion = VALUES(fecha_realizacion),
    codigo_responsable = VALUES(codigo_responsable)
""")

# Confirmar transacciones
conn.commit()

# Cerrar conexión
cursor.close()
conn.close()

# Conexión inicial a MongoDB
client = MongoClient("mongodb://localhost:27017/")

# Crear o obtener la base de datos
db = client['Informatica1_PF']

# Crear el usuario con los roles adecuados
db.command("createUser", "informatica1",
           pwd="info2024",
           roles=[{"role": "readWrite", "db": "Informatica1_PF"}])

# Cerrar esta conexión para reconectar con la nueva base de datos y el nuevo usuario
client.close()

# Conexión a la nueva base de datos con el nuevo usuario
client = MongoClient("mongodb://informatica1:info2024@localhost:27017/Informatica1_PF")
db = client.Informatica1_PF

# Colección de responsables
responsables_collection = db.Responsables
pruebas_collection = db.ResultadosPruebas

# Limpiar las colecciones antes de insertar datos
responsables_collection.delete_many({})
pruebas_collection.delete_many({})

# Datos de ejemplo para responsables
responsables_data = [
    {
        "codigo_responsable": 1,
        "contrasena": "password123",
        "apellido": "Garcia",
        "nombre": "Juan",
        "numero_documento": 12345678,
        "cargo": "Ingeniero"
    },
    {
        "codigo_responsable": 2,
        "contrasena": "password456",
        "apellido": "Martinez",
        "nombre": "Ana",
        "numero_documento": 87654321,
        "cargo": "Tecnico"
    }
]

# Insertar datos de ejemplo en responsables
responsables_collection.insert_many(responsables_data)

# Datos de ejemplo para pruebas
pruebas_data = [
    {
        "serial_probeta": 101,
        "nombre_material": "Acero",
        "resultado_traccion": 0.25,
        "resultado_dureza": 60,
        "resultado_hemocompatibilidad": True,
        "resultado_inflamabilidad": False,
        "resultado_densidad": 7.85,
        "resultado_temperatura_fusion": 1500,
        "fecha_realizacion": datetime(2024, 5, 1),
        "codigo_responsable": 1
    },
    {
        "serial_probeta": 102,
        "nombre_material": "Aluminio",
        "resultado_traccion": 0.30,
        "resultado_dureza": 35,
        "resultado_hemocompatibilidad": False,
        "resultado_inflamabilidad": True,
        "resultado_densidad": 2.70,
        "resultado_temperatura_fusion": 660,
        "fecha_realizacion": datetime(2024, 5, 2),
        "codigo_responsable": 2
    }
]

# Insertar datos de ejemplo en pruebas
pruebas_collection.insert_many(pruebas_data)

# Cerrar conexión
client.close()

    





